
Initial architecture and prototype scaffold
